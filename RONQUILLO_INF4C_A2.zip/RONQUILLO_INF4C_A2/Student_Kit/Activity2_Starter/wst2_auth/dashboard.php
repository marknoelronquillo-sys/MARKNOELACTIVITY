
<?php
// dashboard.php – ACTIVITY 2
// Protected dashboard with role-based navigation.

require __DIR__ . '/auth.php';

// Only logged-in users can access the dashboard.
require_login();

$pageTitle = 'Dashboard';
require __DIR__ . '/includes/header.php';
?>

<section class="card">
    <h1>Welcome, <?= e($_SESSION['username'] ?? '') ?>!</h1>

    <p>
        You are logged in as
        <strong><?= e($_SESSION['role'] ?? '') ?></strong>.
    </p>

    <h2>Available Pages</h2>

    <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>

        <p>
            <a class="button" href="<?= BASE_URL ?>/admin/manage_users.php">
                Manage Users
            </a>
        </p>

        <p>
            <a class="button" href="<?= BASE_URL ?>/instructor/encode_grades.php">
                Encode Grades
            </a>
        </p>

    <?php elseif (($_SESSION['role'] ?? '') === 'instructor'): ?>

        <p>
            <a class="button" href="<?= BASE_URL ?>/instructor/encode_grades.php">
                Encode Grades
            </a>
        </p>

    <?php elseif (($_SESSION['role'] ?? '') === 'student'): ?>

        <p>
            <a class="button" href="<?= BASE_URL ?>/student/my_grades.php">
                My Grades
            </a>
        </p>

    <?php endif; ?>

</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
